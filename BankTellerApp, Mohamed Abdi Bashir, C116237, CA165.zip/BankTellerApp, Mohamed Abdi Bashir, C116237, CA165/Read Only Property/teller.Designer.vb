﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class teller
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBoxAmount = New System.Windows.Forms.TextBox()
        Me.ButtonDeposit = New System.Windows.Forms.Button()
        Me.ButtonWithdraw = New System.Windows.Forms.Button()
        Me.LabelBalance = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(129, 207)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = " Amount"
        '
        'TextBoxAmount
        '
        Me.TextBoxAmount.Location = New System.Drawing.Point(226, 201)
        Me.TextBoxAmount.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxAmount.Name = "TextBoxAmount"
        Me.TextBoxAmount.Size = New System.Drawing.Size(100, 26)
        Me.TextBoxAmount.TabIndex = 1
        '
        'ButtonDeposit
        '
        Me.ButtonDeposit.Location = New System.Drawing.Point(15, 169)
        Me.ButtonDeposit.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ButtonDeposit.Name = "ButtonDeposit"
        Me.ButtonDeposit.Size = New System.Drawing.Size(97, 35)
        Me.ButtonDeposit.TabIndex = 2
        Me.ButtonDeposit.Text = "Deposit"
        Me.ButtonDeposit.UseVisualStyleBackColor = True
        '
        'ButtonWithdraw
        '
        Me.ButtonWithdraw.Location = New System.Drawing.Point(15, 232)
        Me.ButtonWithdraw.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ButtonWithdraw.Name = "ButtonWithdraw"
        Me.ButtonWithdraw.Size = New System.Drawing.Size(97, 35)
        Me.ButtonWithdraw.TabIndex = 3
        Me.ButtonWithdraw.Text = "Withdraw"
        Me.ButtonWithdraw.UseVisualStyleBackColor = True
        '
        'LabelBalance
        '
        Me.LabelBalance.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.LabelBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabelBalance.Location = New System.Drawing.Point(376, 232)
        Me.LabelBalance.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelBalance.Name = "LabelBalance"
        Me.LabelBalance.Size = New System.Drawing.Size(97, 35)
        Me.LabelBalance.TabIndex = 4
        Me.LabelBalance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(222, 239)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(124, 20)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Current Balance"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(129, 36)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 20)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Enter Acc"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(226, 33)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 26)
        Me.TextBox1.TabIndex = 6
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(376, 33)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 29)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "Find"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(129, 91)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(82, 20)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Acc Name"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(226, 91)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(132, 26)
        Me.TextBox2.TabIndex = 9
        '
        'teller
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(485, 289)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ButtonWithdraw)
        Me.Controls.Add(Me.ButtonDeposit)
        Me.Controls.Add(Me.TextBoxAmount)
        Me.Controls.Add(Me.LabelBalance)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "teller"
        Me.Text = "Teller"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBoxAmount As System.Windows.Forms.TextBox
    Friend WithEvents ButtonDeposit As System.Windows.Forms.Button
    Friend WithEvents ButtonWithdraw As System.Windows.Forms.Button
    Friend WithEvents LabelBalance As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox

End Class
